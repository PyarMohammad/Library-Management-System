from django.apps import AppConfig


class AdmissionappConfig(AppConfig):
    name = 'AdmissionApp'
