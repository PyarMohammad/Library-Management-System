from AdmissionApp import views
from django.conf.urls import url

urlpatterns=[
    url('Admission',views.Admission),
]
