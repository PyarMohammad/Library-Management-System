from django.db import models

class Student(models.Model):
    enr_no=models.IntegerField()
    stu_name=models.CharField(max_length=50)
    course_code=models.CharField(max_length=50)
    stu_addr=models.CharField(max_length=100)
    def __str__(self):
       return self.stu_name
