from django.shortcuts import render
from django.http import HttpResponse
from AdmissionApp import models

def Admission(request):
    students=models.Student.objects.all()
    data={'students':students}
    res=render(request,'AdmissionApp_Template/Admission.html',data)
    return(res)
