from django.contrib import admin
from AdmissionApp.models import Student



admin.site.register(Student)
