from django.contrib import admin
from BRMApp.models import *

admin.site.register(BRMuser)
